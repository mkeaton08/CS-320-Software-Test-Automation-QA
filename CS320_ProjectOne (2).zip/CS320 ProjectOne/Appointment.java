/* Matthew Keaton  
 * Date: 04/06/2025
 * Course: CS 320
 * Assignment: 5-1 Milestone Appointment Service
 */

import java.util.Date; // Import the Date for appointment date field

public class Appointment {
    private final String appointmentId; // Not updatable unique ID
    private Date appointmentDate;
    private String description;

    // Constructor to create a new Appointment
    public Appointment(String appointmentId, Date appointmentDate, String description) {
    	
    	// Conditions to meet requirements
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID.");
        }
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Date must not be in the past.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description.");
        }

        // Set values
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Create getters
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }
}