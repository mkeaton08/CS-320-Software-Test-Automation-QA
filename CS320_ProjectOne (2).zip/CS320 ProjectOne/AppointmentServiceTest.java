/* Matthew Keaton  
 * Date: 04/06/2025
 * Course: CS 320
 * Assignment: 5-1 Milestone Appointment Service
 */

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date; // Import date for date fields
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	// Method to create a valid future date
    private Date futureDate() {
        long now = System.currentTimeMillis();
        long oneDay = 86400000;     // One day in milliseconds
        return new Date(now + oneDay);
    }

    // Test to add a valid appointment
    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("369", futureDate(), "Appointment");
        service.addAppointment(appt);

        // Ensure it was added
        Appointment found = service.getAppointment("369");
        assertNotNull(found); // Should not be null
        assertEquals("Appointment", found.getDescription()); // Check description
    }

    // Test for duplicate appointment IDs
    @Test
    public void testDuplicateIdNotAllowed() {
        AppointmentService service = new AppointmentService(); 
        Appointment a1 = new Appointment("246", futureDate(), "Appointment");
        Appointment a2 = new Appointment("246", futureDate(), "Checkup");

        service.addAppointment(a1); // Add first one

        // Try to add a2 with same ID
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(a2);
        });
    }

    // Test to delete an appointment
    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("456", futureDate(), "Haircut");
        service.addAppointment(appt);
        service.deleteAppointment("456");

        // Appointment shouldn't be found
        assertNull(service.getAppointment("456"));
    }

    // Test deleting an appointment that doesn't exist
    @Test
    public void testDeleteNonexistentAppointment() {
        AppointmentService service = new AppointmentService();

        // Try to delete an appointment that was never added
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}
