/* Matthew Keaton  
 * Date: 03/30/2025
 * Course: CS 320
 * Assignment: 4-1 Milestone Task Service
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {
    // Test task with valid data
    @Test
    public void testCreateTaskSuccessfully() {
        Task task = new Task("555", "Testing", "Complete the testing"); // Create task
        assertEquals("555", task.getTaskId()); // Check task ID
        assertEquals("Testing", task.getName()); // Check task name
        assertEquals("Complete the testing", task.getDescription()); // Check task description
    }

    // Test that invalid IDs are rejected
    @Test
    public void testInvalidTaskId() {
        // Null task ID should throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });

        // Task ID longer than 10 characters should throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678999", "Name", "Description");
        });
    }

    // Test that null name is rejected
    @Test
    public void testInvalidNameAndDescription() {
        // Null name should throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", null, "Description");
        });

        // Null description should throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("456", "Name", null);
        });
    }

    // Test that setters update name and description
    @Test
    public void testSetters() {
        Task task = new Task("789", "Old Name", "Old Description"); // Create task with initial values
        task.setName("New Name");
        task.setDescription("New Description"); 

        // Confirm that updates were successful
        assertEquals("New Name", task.getName());
        assertEquals("New Description", task.getDescription());
    }
}