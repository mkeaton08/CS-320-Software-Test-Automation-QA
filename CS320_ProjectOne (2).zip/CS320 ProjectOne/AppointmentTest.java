/* Matthew Keaton  
 * Date: 04/06/2025
 * Course: CS 320
 * Assignment: 5-1 Milestone Appointment Service
 */


import static org.junit.jupiter.api.Assertions.*;
import java.util.Date; // import date for date fields
import org.junit.jupiter.api.Test;

class AppointmentTest {

	// Method to get a valid future date test
    private Date getFutureDate() {
        // System.currentTimeMillis() gets current time in milliseconds
        return new Date(System.currentTimeMillis() + 86400000);
    }

    // Method for date in the past for invalid test
    private Date getPastDate() {
        return new Date(System.currentTimeMillis() - 86400000);
    }

    // Create valid appointment
    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("1234567890", futureDate, "Doctor Visit");

        // Check if the ID, date, and description saved
        assertEquals("1234567890", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Doctor Visit", appt.getDescription());
    }

    	// Test appointment with a null ID
    @Test
    public void testNullAppointmentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Check");
        });
    }

    // Test appointment ID longer than 10 characters
    @Test
    public void testLongAppointmentIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getFutureDate(), "Check");
        });
    }

    // Test appointment date that is null
    @Test
    public void testNullDateThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("50505", null, "Description");
        });
    }

    // Test appointment date in the past
    @Test
    public void testPastDateThrowsException() {
        Date pastDate = getPastDate();
        // Try to create an appointment with a past date
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("50505", pastDate, "Description");
        });
    }

    // Test invalid description being null
    @Test
    public void testNullDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("50505", getFutureDate(), null);
        });
    }

    // Test description that is longer than 50 characters
    @Test
    public void testLongDescriptionThrowsException() {
        // Create a string longer than 50 characters
        String longDescription = "Create a description that is definitely longer than the required characters";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("50505", getFutureDate(), longDescription);
        });
    }

    // Test a valid description
    @Test
    public void testValidDescription() {
        Appointment appt = new Appointment("50505", getFutureDate(), "Normal Appointment");
        // Check the description matches
        assertEquals("Normal Appointment", appt.getDescription());
    }
}