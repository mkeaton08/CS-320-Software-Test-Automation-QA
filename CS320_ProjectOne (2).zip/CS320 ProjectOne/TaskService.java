/* Matthew Keaton  
 * Date: 03/30/2025
 * Course: CS 320
 * Assignment: 4-1 Milestone Task Service
 */

import java.util.ArrayList;

public class TaskService {
    // Store tasks in a list
    private ArrayList<Task> tasks = new ArrayList<>();

    // Add a new task
    public void addTask(String taskId, String name, String description) {
        // Check if a task with the same ID already exists
        for (int i = 0; i < tasks.size(); ++i) {
            if (tasks.get(i).getTaskId().equals(taskId)) {
                throw new IllegalArgumentException("Already exists.");
            }
        }

        // Create and add the task
        Task newTask = new Task(taskId, name, description);
        tasks.add(newTask);
    }

    // Delete a task using the task ID
    public void deleteTask(String taskId) {
        for (int i = 0; i < tasks.size(); ++i) {
            if (tasks.get(i).getTaskId().equals(taskId)) {
                tasks.remove(i);
                return;
            }
        }
        throw new IllegalArgumentException("Not found.");
    }

    // Update the name of a task using the task ID
    public void updateTaskName(String taskId, String newName) {
        for (int i = 0; i < tasks.size(); ++i) {
            if (tasks.get(i).getTaskId().equals(taskId)) {
                tasks.get(i).setName(newName);
                return;
            }
        }
        throw new IllegalArgumentException("Not found.");
    }

    // Update the description of a task using the task ID
    public void updateTaskDescription(String taskId, String newDescription) {
        for (int i = 0; i < tasks.size(); ++i) {
            if (tasks.get(i).getTaskId().equals(taskId)) {
                tasks.get(i).setDescription(newDescription);
                return;
            }
        }
        throw new IllegalArgumentException("Not found.");
    }

    // Get a task by ID
    public Task getTask(String taskId) {
        for (int i = 0; i < tasks.size(); ++i) {
            if (tasks.get(i).getTaskId().equals(taskId)) {
                return tasks.get(i);
            }
        }
        return null;
    }
}