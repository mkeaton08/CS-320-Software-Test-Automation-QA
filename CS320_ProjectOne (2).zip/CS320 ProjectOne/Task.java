/* Matthew Keaton  
 * Date: 03/30/2025
 * Course: CS 320
 * Assignment: 4-1 Milestone Task Service
 */

public class Task {
    // Declare variables
    private final String taskId;
    private String name;
    private String description;

    // Constructor
    public Task(String taskId, String name, String description) {
        // Check for valid task ID
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException();
        }

        // Check for valid name
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException();
        }

        // Check for valid description
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException();
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Setters
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException();
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException();
        }
        this.description = description;
    }
    // Getters
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}
