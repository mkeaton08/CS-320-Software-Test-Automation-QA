/* Matthew Keaton  
 * Date: 03/30/2025
 * Course: CS 320
 * Assignment: 4-1 Milestone Task Service
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;          // Import BeforeEach from J unit 5 library
import org.junit.jupiter.api.Test;            

public class TaskServiceTest {
	// Declare TaskService object
    private TaskService taskService; 

    // Method runs before each test 
    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    // Test that a task can be added
    @Test
    public void testAddTask() {
        taskService.addTask("101", "Run", "Run for at least 30 minutes"); // Add a new task
        Task task = taskService.getTask("101");
        assertNotNull(task); // Make sure the task was added
        assertEquals("Run", task.getName()); // Check for run
    }

    // Test that duplicate task ID throws exception
    @Test
    public void testAddDuplicateTask() {
        taskService.addTask("101", "watch show", "Watch season 2 of show"); // Add the first task
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask("101", "Watch Tv", "Watch season 3 of show"); // Try to add a second task with same ID
        });
    }

    // Test that a task can be deleted
    @Test
    public void testDeleteTask() {
        taskService.addTask("102", "workout", "Go to gym for 30 minutes");
        taskService.deleteTask("102");
        assertNull(taskService.getTask("102"));
    }

    // Test updating the name of an existing task
    @Test
    public void testUpdateName() {
        taskService.addTask("103", "Old Name", "Some description"); // Add a task
        taskService.updateTaskName("103", "New Name"); // Update the task's name
        assertEquals("New Name", taskService.getTask("103").getName()); // Verify the update
    }

    // Test updating the description of an existing task
    @Test
    public void testUpdateDescription() {
        taskService.addTask("104", "Task Name", "Old description"); 
        taskService.updateTaskDescription("104", "Updated description"); 
        assertEquals("Updated description", taskService.getTask("104").getDescription());
    }

    // Test for updating a task that doesn't exist to throw an exception
    @Test
    public void testUpdateInvalidTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTaskName("999", "Does not exist");
        });
    }
}
