/* Matthew Keaton  
 * Date: 04/06/2025
 * Course: CS 320
 * Assignment: 5-1 Milestone Appointment Service
 */


import java.util.Vector; // Import Vector

public class AppointmentService {

    // Create a Vector to store objects
    private final Vector<Appointment> appointments = new Vector<>();

    // Add a new appointment
    public void addAppointment(Appointment appointment) {
        // Loop through vector to check if the ID already exists
        for (Appointment appt : appointments) {
            if (appt.getAppointmentId().equals(appointment.getAppointmentId())) {
                throw new IllegalArgumentException("Appointment ID already exists.");
            }
        }

        // Add appointment to vector
        appointments.add(appointment);
    }

    // Delete an appointment by ID
    public void deleteAppointment(String appointmentId) {
        // Loop to find the appointment with ID
        for (int i = 0; i < appointments.size(); i++) {
            if (appointments.get(i).getAppointmentId().equals(appointmentId)) {
                appointments.remove(i);
                return;
            }
        }
        // If ID not found throw error
        throw new IllegalArgumentException("Appointment ID not found.");
    }

    // Find appointment by ID
    public Appointment getAppointment(String appointmentId) {
        // Loop to find appointment
        for (Appointment appt : appointments) {
            if (appt.getAppointmentId().equals(appointmentId)) {
                return appt;
            }
        }
        // Return null if not found
        return null;
    }
}
